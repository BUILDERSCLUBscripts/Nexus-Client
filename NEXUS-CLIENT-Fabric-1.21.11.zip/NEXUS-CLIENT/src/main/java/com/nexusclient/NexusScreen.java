package com.nexusclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class NexusScreen extends Screen {
    private static final int RED = 0xFFE53945;
    private static final int DARK = 0xF0181A20;
    private static final int PANEL = 0xFF22252D;
    private static final int MUTED = 0xFFAAAEB8;

    private String activePanel = "Player";

    public NexusScreen() {
        super(Component.literal("NEXUS CLIENT"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 165;
        int top = this.height / 2 - 105;

        addRenderableWidget(Button.builder(Component.literal("Player"), b -> select("Player"))
                .bounds(left + 12, top + 48, 72, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Visuals"), b -> select("Visuals"))
                .bounds(left + 88, top + 48, 72, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Settings"), b -> select("Settings"))
                .bounds(left + 164, top + 48, 72, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Misc"), b -> select("Misc"))
                .bounds(left + 240, top + 48, 72, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(left + 250, top + 176, 62, 20).build());
    }

    private void select(String panel) {
        activePanel = panel;
        clearWidgets();
        init();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);

        int left = this.width / 2 - 165;
        int top = this.height / 2 - 105;

        graphics.fill(left, top, left + 330, top + 205, DARK);
        graphics.fill(left, top, left + 330, top + 3, RED);
        graphics.fill(left + 10, top + 10, left + 320, top + 38, PANEL);

        graphics.drawString(this.font, "NEXUS CLIENT", left + 18, top + 19, RED, true);
        graphics.drawString(this.font, "1.21.11  |  CLIENT MENU", left + 205, top + 20, MUTED, false);

        graphics.fill(left + 10, top + 76, left + 320, top + 166, PANEL);
        graphics.drawString(this.font, activePanel.toUpperCase(), left + 22, top + 88, RED, true);

        switch (activePanel) {
            case "Player" -> {
                graphics.drawString(this.font, "Player panel", left + 22, top + 108, 0xFFFFFFFF);
                graphics.drawString(this.font, "Aquí añadiremos opciones visuales del jugador.", left + 22, top + 126, MUTED);
            }
            case "Visuals" -> {
                graphics.drawString(this.font, "Visual settings", left + 22, top + 108, 0xFFFFFFFF);
                graphics.drawString(this.font, "Aquí irán los ajustes de interfaz y pantalla.", left + 22, top + 126, MUTED);
            }
            case "Settings" -> {
                graphics.drawString(this.font, "Client settings", left + 22, top + 108, 0xFFFFFFFF);
                graphics.drawString(this.font, "Configuración general de NEXUS CLIENT.", left + 22, top + 126, MUTED);
            }
            default -> {
                graphics.drawString(this.font, "Miscellaneous", left + 22, top + 108, 0xFFFFFFFF);
                graphics.drawString(this.font, "Más funciones y accesos rápidos próximamente.", left + 22, top + 126, MUTED);
            }
        }

        graphics.drawString(this.font, "RIGHT SHIFT  •  OPEN / CLOSE", left + 14, top + 184, MUTED);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
