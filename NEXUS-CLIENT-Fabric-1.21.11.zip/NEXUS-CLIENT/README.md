# NEXUS CLIENT

Cliente visual para Minecraft Java 1.21.11 + Fabric.

## Incluye
- Menú rojo estilo client, con pestañas Player, Visuals, Settings y Misc.
- Abrir/cerrar con **Shift derecho**.
- Mensaje de bienvenida al entrar en un mundo o servidor.
- Menú no pausa el juego.

## Requisitos
- Minecraft Java 1.21.11
- Java 21
- Fabric Loader (el proyecto está configurado con 0.18.1)
- Fabric API 0.141.1+1.21.11
- Gradle instalado o importación mediante IntelliJ IDEA.

## Compilar
Desde la carpeta del proyecto, ejecuta:

```bash
gradle build
```

El `.jar` aparecerá en `build/libs/`.

Copia el JAR principal a la carpeta `mods` de tu instalación de Fabric 1.21.11.

## Nota
Este primer proyecto es una base inicial. Las pestañas ya funcionan, pero sus paneles contienen texto de marcador de posición; todavía no activan funciones de juego. No se ha ejecutado una compilación de Gradle en este entorno, así que puede requerir ajustes menores al resolver las dependencias.
